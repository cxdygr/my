/**
 * 常量
 * Created by cuiyi on 2017/12/19.
 * email: 1987497713@qq.com
 */
const classify = [{
    id: '0',
    title: '吃喝'
}, {
    id: '1',
    title: '交通'
}, {
    id: '2',
    title: '服饰'
}, {
    id: '3',
    title: '居家'
}, {
    id: '4',
    title: '学习'
}, {
    id: '5',
    title: '金融'
}, {
    id: '6',
    title: '人情'
}, {
    id: '7',
    title: '健康'
}, {
    id: '8',
    title: '娱乐'
}];

let info = {
    classify
};
export default info;