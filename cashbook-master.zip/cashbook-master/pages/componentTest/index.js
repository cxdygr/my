/**
 * 测试自定义组件的功能
 * Created by cuiyi on 2018/1/14.
 */
Page({
    data: {
        title: '自定义组件',
        desc: '适用'
    },
    onTest(e) {
        console.log('test')
    },
    onLoad(params) {

    },
    onReady: function () {
        // Do something when page ready.
    },
    onShow: function () {

    },
    onHide: function () {
        // Do something when page hide.
    },
    onUnload: function () {
        // Do something when page close.
    }
});